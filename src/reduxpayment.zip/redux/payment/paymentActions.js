
import PaymentService from "../../service/PaymentService"
import {
    
    ADD_PAYMENT_REQUEST

} from "./paymentTypes";

export const addPaymentRequest = (pay) => {
       return {
             type: ADD_PAYMENT_REQUEST,
             payload: pay, //data from database
         };
     };


export const addPayment =(pay)  => {
    return (dispatch) => {
        let service = new PaymentService();
        service.addPayment(pay)
            .then((response) => {
                const payment = response.data;
                dispatch(addPaymentRequest(payment));//take action as parameter,reudcer is triggered
            })
            .catch((error) => {
                // dispatch(fetchEmployeesFailure(error.message));
            });
    };
};


