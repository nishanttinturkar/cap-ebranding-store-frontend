import {
    
    ADD_PAYMENT_REQUEST,
    
} from "./paymentTypes";

const initialState = {
    loading: false,
    payments: [],
    payment: {},
    error: "",
};

const reducer = (state = initialState, action) => {//state transition n home comp updated
    switch (action.type) {
        case ADD_PAYMENT_REQUEST:
            return {
                ...state,
                payments: [...state.payments, action.payload],//emp data
            }
            default:
            return state;
    }
   
 };
 export default reducer;
            